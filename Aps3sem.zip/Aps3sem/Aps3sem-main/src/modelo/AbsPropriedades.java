
package modelo;


public abstract class AbsPropriedades 
{
    public String resposta;   
    public String nome;
    public String resp1;
    public String resp2;
    public String resp3;
    public String resp4;
    public String resp5;
    

 
    
}
