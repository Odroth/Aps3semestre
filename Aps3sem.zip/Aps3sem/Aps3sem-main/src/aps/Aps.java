
package aps;

import apresentacao.*;

public class Aps
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        frmInicial frmI = new frmInicial(null, true);
        frmI.setVisible(true);
    } 
    
}
