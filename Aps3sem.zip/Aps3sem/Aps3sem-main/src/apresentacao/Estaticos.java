
package apresentacao;


public class Estaticos
{
    public static int SOMA;
    public static String TEXTO;
    public static String MENSAGEM;
    public static String NOME;
    public static String RESP1;
    public static int SOMAACERTOS;
    public static String ACERTOS;
}
